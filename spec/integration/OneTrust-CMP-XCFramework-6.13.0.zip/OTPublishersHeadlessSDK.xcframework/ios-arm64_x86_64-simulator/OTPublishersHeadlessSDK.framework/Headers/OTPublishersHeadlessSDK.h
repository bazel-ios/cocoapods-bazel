//
//  OTPublishersHeadlessSDK.h
//  OTPublishersHeadlessSDK
//
//  Created by OneTrust on 19/06/20.
//  Copyright © 2020 OneTrust. All rights reserved.
//

#ifndef OTPublishersHeadlessSDK_h
#define OTPublishersHeadlessSDK_h

#include "TCF2Encoder.h"

#endif /* OTPublishersHeadlessSDK_h */
